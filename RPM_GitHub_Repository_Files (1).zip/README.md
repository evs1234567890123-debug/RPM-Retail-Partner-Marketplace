# RPM — Retail Partner Marketplace

**HSC 2027 concept prototype** | Neighbourhood shops. Digital reach. Fairer local commerce.

RPM is a student concept for a shared digital platform connecting neighbourhood customers, local kirana/general stores, and local delivery partners. The idea is to help participating shops list products online and serve nearby customers using their existing inventory rather than operating central dark stores.

> **Status:** Front-end demonstration prototype only. RPM is not a live business or production-ready service. Sample stores, products, prices, orders, and flows are illustrative.

## Run the demo

1. Download or clone this repository.
2. Open `index.html` in Chrome, Edge, Firefox, or another modern browser.
3. Switch between **Customer**, **Shopkeeper**, and **Delivery Partner** modes using the buttons at the top.
4. In Customer mode, search and browse items, add items to the basket, enter a demo address, and place a mock order.
5. In Shopkeeper mode, view the mock order queue and add a sample product.
6. In Delivery Partner mode, review the demo task and update its status.

No installation or build tools are required for this static prototype.

## Repository contents

- `index.html` — self-contained HTML/CSS/JavaScript prototype.
- `README.md` — overview and setup instructions.
- `architecture.md` — current design, proposed future architecture, and limitations.
- `sample_data.json` — fictional sample stores, products, and test data.
- `TEST_CASES.md` — manual test cases and expected outcomes.
- `LICENSE` — MIT license for this concept prototype.
- `RPM_HSC_2027_Pitch.pptx` — draft pitch deck for reference; the official MY Bharat template may need to be used for final portal submission.

## Prototype limitations

This demo has no real authentication, backend, database, live stock synchronisation, payments, GPS, notifications, refunds, settlements, or actual delivery integrations. Its sample data and state are stored in the browser and reset when refreshed. Do not enter real personal data. Do not present the demo as a live service.

## Proposed pilot and impact metrics

A small pilot in one Bihar neighbourhood could test the idea with interested shops only after their consent. Suggested measures are: number of onboarded stores, orders accepted, order fulfilment rate, cancellation rate, average time to prepare and deliver, repeat purchases, retailer satisfaction, customer satisfaction, and transparent fees per order. These are proposed metrics, not achieved results.

## Responsible presentation

- Do not claim RPM is India's first or that it is already operating.
- Do not promise guaranteed 10-minute delivery. Delivery estimates must be tested locally.
- Treat all pilot metrics as targets until measured.
- Similar models already exist in India; the project should validate its value through affordable onboarding, clear fees, local-language usability, shared delivery, and measured outcomes for retailers.
- AI assistance was used to help draft the concept, prototype, and documents. The participant should review, understand, adapt, and disclose AI assistance accurately as required by the competition.

## Suggested next steps

1. Confirm the MY Bharat portal's current deadline, eligibility, and document requirements in the participant account.
2. Adapt the pitch to the official MY Bharat template.
3. Record a 3–5 minute screen demo if submitting one.
4. Interview local shopkeepers and customers to validate the problem before making claims about impact.

## Public research links

- MY Bharat — Hack for Social Cause: https://mybharat.gov.in/pages/hack-for-social-cause
- Kiko Live: https://kiko.live/
- PhonePe Pincode press release: https://www.phonepe.com/press/phonepes-pincode-empowers-offline-retailers-digitalises-over-1000-offline-stores/
- Economic Times — local kirana stores and quick-commerce: https://economictimes.indiatimes.com/small-biz/sme-sector/reinventing-retail-how-local-kirana-stores-are-adapting-to-indias-quick-commerce-boom/articleshow/122082309.cms
