# RPM Prototype — Manual Test Cases

These tests are for the local front-end demo. They do not test a production backend or real delivery integrations.

| ID | Test | Steps | Expected result |
|---|---|---|---|
| TC-01 | Search catalogue | Open Customer mode and search for `rice`. | Matching rice listing is shown. |
| TC-02 | Add item to basket | Add any product to basket. | Basket count and subtotal increase. |
| TC-03 | Address validation | Attempt checkout without entering a demo address. | Checkout prompts for an address and does not place the mock order. |
| TC-04 | Create mock order | Add a product, enter a fictional demo address, and place the order. | A mock order appears in customer/shopkeeper/rider demo views as implemented. |
| TC-05 | Shopkeeper catalogue | Switch to Shopkeeper mode and add a sample product. | The product is available in the local demo catalogue. |
| TC-06 | Rider status | Switch to Delivery Partner mode and update a sample task status. | The sample task status changes in the demo interface. |
| TC-07 | Refresh reset | Refresh the page after creating demo data. | In-memory demo state resets; there is no persistent database. |

## Test evidence

Before submission, the participant can add screenshots or actual test outcomes here. Do not state that a test passed unless it has been run and checked.
