# Prototype architecture

## Type
A single-page front-end proof of concept built with HTML, CSS and vanilla JavaScript. It runs locally in a browser with no build tools or backend.

## Components
- **Customer experience:** catalogue search and category filtering, basket quantities, transparent mock delivery fee, demo checkout and order status.
- **Shopkeeper experience:** sample order queue and local-only product creation.
- **Delivery partner experience:** sample task board and safe-delivery checklist.
- **Shared local state:** in-memory JavaScript arrays hold sample product and order objects. Refreshing the page resets state.

## Proposed production architecture (future work only)
- Mobile/web frontend for customer, merchant and rider roles.
- Auth and role-based access control.
- Backend API for stores, product catalogues, availability, orders, refunds and settlements.
- Database for users, store locations, stock, orders and event logs.
- Dispatch service using distance, pickup readiness, delivery capacity and delivery promises; no rider should be forced to accept a job.
- Payment gateway and settlement reconciliation after legal/compliance review.
- Notification service for order status and stock substitutions.
- Privacy controls: collect only necessary customer address/contact information, define retention periods and restrict rider access to assigned orders.

## Current limitations
No real authentication, database, APIs, payment processing, GPS, inventory synchronisation, notifications, merchant onboarding or live delivery. This demo is not production-ready and must not be represented as a live commercial service.
